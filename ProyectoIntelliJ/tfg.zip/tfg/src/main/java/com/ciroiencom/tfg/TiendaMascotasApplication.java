package com.ciroiencom.tfg;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TiendaMascotasApplication {

	public static void main(String[] args) {
		SpringApplication.run(TiendaMascotasApplication.class, args);
	}

}

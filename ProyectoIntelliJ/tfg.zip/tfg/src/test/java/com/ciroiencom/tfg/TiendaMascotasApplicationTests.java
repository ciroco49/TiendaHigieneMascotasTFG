package com.ciroiencom.tfg;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TiendaMascotasApplicationTests {

	@Test
	void contextLoads() {
	}

}
